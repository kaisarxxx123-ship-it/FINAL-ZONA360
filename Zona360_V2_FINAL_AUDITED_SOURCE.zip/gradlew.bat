@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "GV=8.9"
set "DIST=%ROOT%.gradle-dist"
set "GRADLE_HOME=%DIST%\gradle-%GV%"
set "ZIP=%DIST%\gradle-%GV%-bin.zip"
if not exist "%DIST%" mkdir "%DIST%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo [Zona360] Gradle %GV% belum ada. Mengunduh sekali...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GV%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '%DIST%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
